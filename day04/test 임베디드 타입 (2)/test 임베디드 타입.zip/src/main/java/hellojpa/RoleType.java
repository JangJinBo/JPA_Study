package hellojpa;

public enum RoleType {
    GUEST, USER, ADMIN
}
